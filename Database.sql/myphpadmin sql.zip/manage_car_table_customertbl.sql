
-- --------------------------------------------------------

--
-- Table structure for table `customertbl`
--
-- Creation: Aug 01, 2025 at 01:07 PM
-- Last update: Aug 01, 2025 at 06:08 PM
--

DROP TABLE IF EXISTS `customertbl`;
CREATE TABLE `customertbl` (
  `CustId` int(225) NOT NULL,
  `CustName` varchar(250) NOT NULL,
  `CustAdd` int(20) NOT NULL,
  `CustPhone` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `customertbl`:
--

--
-- Dumping data for table `customertbl`
--

INSERT INTO `customertbl` (`CustId`, `CustName`, `CustAdd`, `CustPhone`) VALUES
(9, 'ali', 90, 234243),
(1990, 'Ali Raza', 988889, 909009),
(1991, 'Imran Khan', 4677, 12345678),
(1992, 'Obaid Ullah', 762, 123456789);

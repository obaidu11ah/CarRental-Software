
-- --------------------------------------------------------

--
-- Table structure for table `returntbl`
--
-- Creation: Aug 01, 2025 at 04:19 PM
--

DROP TABLE IF EXISTS `returntbl`;
CREATE TABLE `returntbl` (
  `ReturnIdTb` int(50) NOT NULL,
  `RegTb` int(50) NOT NULL,
  `CustName` varchar(255) NOT NULL,
  `ReturnDate` date NOT NULL,
  `DelayTb` int(20) NOT NULL,
  `FineTb` decimal(11,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `returntbl`:
--

--
-- Dumping data for table `returntbl`
--

INSERT INTO `returntbl` (`ReturnIdTb`, `RegTb`, `CustName`, `ReturnDate`, `DelayTb`, `FineTb`) VALUES
(12, 1101, 'obaid', '2025-08-22', 1, 1000),
(12, 1101, 'obaid', '2025-08-22', 1, 1000),
(10, 1102, 'ALI Hassan', '2025-08-14', 0, 0),
(1001, 456, 'obaid', '2025-08-23', 1, 1000);

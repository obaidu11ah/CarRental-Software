

--
-- Metadata
--
USE `phpmyadmin`;

--
-- Metadata for table car_rigistration
--

--
-- Metadata for table customertbl
--

--
-- Metadata for table renttbl
--

--
-- Metadata for table returntbl
--

--
-- Metadata for database manage car
--

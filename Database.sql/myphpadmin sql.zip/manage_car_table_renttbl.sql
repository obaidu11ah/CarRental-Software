
-- --------------------------------------------------------

--
-- Table structure for table `renttbl`
--
-- Creation: Aug 01, 2025 at 05:10 PM
-- Last update: Aug 01, 2025 at 06:09 PM
--

DROP TABLE IF EXISTS `renttbl`;
CREATE TABLE `renttbl` (
  `RentId` int(50) NOT NULL,
  `CarReg` text NOT NULL,
  `CustName` varchar(225) NOT NULL,
  `RentDate` date NOT NULL,
  `ReturnDate` date NOT NULL,
  `RentFee` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `renttbl`:
--

--
-- Dumping data for table `renttbl`
--

INSERT INTO `renttbl` (`RentId`, `CarReg`, `CustName`, `RentDate`, `ReturnDate`, `RentFee`) VALUES
(1001, 'LXB-767', 'Obaid Ullah', '2025-08-20', '2025-08-21', 2000);

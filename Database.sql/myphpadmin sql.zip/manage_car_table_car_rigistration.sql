
-- --------------------------------------------------------

--
-- Table structure for table `car_rigistration`
--
-- Creation: Aug 01, 2025 at 03:33 PM
-- Last update: Aug 01, 2025 at 06:09 PM
--

DROP TABLE IF EXISTS `car_rigistration`;
CREATE TABLE `car_rigistration` (
  `RegNumTb` varchar(20) NOT NULL,
  `BrandTb` varchar(100) NOT NULL,
  `ModelTb` varchar(100) NOT NULL,
  `StatusCb` varchar(100) NOT NULL,
  `PriceTb` decimal(50,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `car_rigistration`:
--

--
-- Dumping data for table `car_rigistration`
--

INSERT INTO `car_rigistration` (`RegNumTb`, `BrandTb`, `ModelTb`, `StatusCb`, `PriceTb`) VALUES
('LHR-1234', 'Toyota', 'Corolla 2020', 'Available', 2000),
('ISB-5678', 'Honda', 'Civic 2021', 'Booked', 5000);
